#ifndef _SPEAKER_H
#define _SPEAKER_H


#include <iostream>
#include <string>
using namespace std;

class Speaker{
    public:
        string m_Name;
        double m_Score[2];  //分数  最多有两轮得分
};

#endif